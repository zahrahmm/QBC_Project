import OrderTable from "../components/orders/orderTable";

function orders() {
  return (
    <>
      <OrderTable />
    </>
  );
}

export default orders;
