import { NavLink } from "react-router";
import User from "./User";
import Admin from "./Admin";
import { useAuthStore } from "../../stores/useAuthStore";
// import { useLogin } from "../../utils/login";

function Menu() {
  // const { data: user } = useLogin();
  // const id = localStorage.getItem("id");
  // const admin = localStorage.getItem("admin");
  const { user } = useAuthStore();

  return (
    <div>
      <ul className="menu bg-base-300 rounded-box gap-16">
        <li className="tooltip tooltip-left" data-tip="خانه">
          <NavLink
            className={({ isActive }) => (isActive ? "text-secondary" : "")}
            to="/"
          >
            <svg
              xmlns="http://www.w3.org/2000/svg"
              fill="none"
              viewBox="0 0 24 24"
              strokeWidth={1.5}
              stroke="currentColor"
              className="size-6"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                d="m2.25 12 8.954-8.955c.44-.439 1.152-.439 1.591 0L21.75 12M4.5 9.75v10.125c0 .621.504 1.125 1.125 1.125H9.75v-4.875c0-.621.504-1.125 1.125-1.125h2.25c.621 0 1.125.504 1.125 1.125V21h4.125c.621 0 1.125-.504 1.125-1.125V9.75M8.25 21h8.25"
              />
            </svg>
            <p className="hidden">داشبورد</p>
          </NavLink>
        </li>
        <li className="tooltip tooltip-left" data-tip="فروشگاه">
          <NavLink
            className={({ isActive }) => (isActive ? "text-secondary" : "")}
            to="/Shop"
          >
            <svg
              xmlns="http://www.w3.org/2000/svg"
              fill="none"
              viewBox="0 0 24 24"
              strokeWidth={1.5}
              stroke="currentColor"
              className="size-6"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                d="M15.75 10.5V6a3.75 3.75 0 1 0-7.5 0v4.5m11.356-1.993 1.263 12c.07.665-.45 1.243-1.119 1.243H4.25a1.125 1.125 0 0 1-1.12-1.243l1.264-12A1.125 1.125 0 0 1 5.513 7.5h12.974c.576 0 1.059.435 1.119 1.007ZM8.625 10.5a.375.375 0 1 1-.75 0 .375.375 0 0 1 .75 0Zm7.5 0a.375.375 0 1 1-.75 0 .375.375 0 0 1 .75 0Z"
              />
            </svg>
            <p className="hidden">فروشگاه</p>
          </NavLink>
        </li>
        <li className="tooltip tooltip-left" data-tip="سبد خرید">
          <NavLink
            className={({ isActive }) => (isActive ? "text-secondary" : "")}
            to="/Cart"
          >
            <div className="indicator">
              {/* تعداد باید طبق تعداد لیست باشد */}
              <span className="indicator-item badge badge-secondary rounded-full size-5">
                ۱
              </span>
              <svg
                xmlns="http://www.w3.org/2000/svg"
                fill="none"
                viewBox="0 0 24 24"
                strokeWidth={1.5}
                stroke="currentColor"
                className="size-6 join-item"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  d="M2.25 3h1.386c.51 0 .955.343 1.087.835l.383 1.437M7.5 14.25a3 3 0 0 0-3 3h15.75m-12.75-3h11.218c1.121-2.3 2.1-4.684 2.924-7.138a60.114 60.114 0 0 0-16.536-1.84M7.5 14.25 5.106 5.272M6 20.25a.75.75 0 1 1-1.5 0 .75.75 0 0 1 1.5 0Zm12.75 0a.75.75 0 1 1-1.5 0 .75.75 0 0 1 1.5 0Z"
                />
              </svg>
              <p className="hidden">سبد خرید</p>
            </div>
          </NavLink>
        </li>
        <li className="tooltip tooltip-left" data-tip="علاقه‌مندی‌ها">
          <NavLink
            className={({ isActive }) => (isActive ? "text-secondary" : "")}
            to="/Fave"
          >
            <svg
              xmlns="http://www.w3.org/2000/svg"
              viewBox="0 0 24 24"
              fill="currentColor"
              className="size-6"
            >
              <path d="m11.645 20.91-.007-.003-.022-.012a15.247 15.247 0 0 1-.383-.218 25.18 25.18 0 0 1-4.244-3.17C4.688 15.36 2.25 12.174 2.25 8.25 2.25 5.322 4.714 3 7.688 3A5.5 5.5 0 0 1 12 5.052 5.5 5.5 0 0 1 16.313 3c2.973 0 5.437 2.322 5.437 5.25 0 3.925-2.438 7.111-4.739 9.256a25.175 25.175 0 0 1-4.244 3.17 15.247 15.247 0 0 1-.383.219l-.022.012-.007.004-.003.001a.752.752 0 0 1-.704 0l-.003-.001Z" />
            </svg>
            <p className="hidden">علاقه‌مندی‌ها</p>
          </NavLink>
        </li>
      </ul>
      {!user && (
        <ul className="absolute bottom-3 menu bg-base-300 rounded-box gap-3">
          <li className="join-item tooltip tooltip-left" data-tip="ورود">
            <NavLink
              className={({ isActive }) => (isActive ? "text-secondary" : "")}
              to="/Login"
            >
              <svg
                xmlns="http://www.w3.org/2000/svg"
                fill="none"
                viewBox="0 0 24 24"
                strokeWidth={1.5}
                stroke="currentColor"
                className="size-6"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  d="M8.25 9V5.25A2.25 2.25 0 0 1 10.5 3h6a2.25 2.25 0 0 1 2.25 2.25v13.5A2.25 2.25 0 0 1 16.5 21h-6a2.25 2.25 0 0 1-2.25-2.25V15M12 9l3 3m0 0-3 3m3-3H2.25"
                />
              </svg>
            </NavLink>
          </li>
          <li className="join-item tooltip tooltip-left" data-tip="ثبت نام">
            <NavLink
              className={({ isActive }) => (isActive ? "text-secondary" : "")}
              to="/Register"
            >
              <svg
                xmlns="http://www.w3.org/2000/svg"
                fill="none"
                viewBox="0 0 24 24"
                strokeWidth={1.5}
                stroke="currentColor"
                className="size-6"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  d="M18 7.5v3m0 0v3m0-3h3m-3 0h-3m-2.25-4.125a3.375 3.375 0 1 1-6.75 0 3.375 3.375 0 0 1 6.75 0ZM3 19.235v-.11a6.375 6.375 0 0 1 12.75 0v.109A12.318 12.318 0 0 1 9.374 21c-2.331 0-4.512-.645-6.374-1.766Z"
                />
              </svg>
            </NavLink>
          </li>
        </ul>
      )}
      {user && !user.isAdmin && <User />}
      {user?.isAdmin && <Admin />}
    </div>
  );
}

export default Menu;
