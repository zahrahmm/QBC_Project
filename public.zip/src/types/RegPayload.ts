export type regPayload = {
  username: string;
  email: string;
  password: string;
  confirm_Password: string;
};
