export type totalsalesModel = {
    totalSales: number
}