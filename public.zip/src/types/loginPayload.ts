export type loginPayload = {
  email: string;
  password: string;
};
